Potted Cactus - Mistbloom Studios
==================================================

A two armed cactus in a terracotta pot. Day 4 (Cactus) of October Prompt Props.

INSTALL - Drag and Drop (Nexo)
--------------
1. Copy Nexo/items/inkprops_cactus.yml into plugins/Nexo/items/
2. Copy the Nexo/pack/assets/ folder into plugins/Nexo/pack/assets/
3. Run /nexo reload all, then /nexo inventory to grab the pieces.

Requires Minecraft 1.21.4 or newer
