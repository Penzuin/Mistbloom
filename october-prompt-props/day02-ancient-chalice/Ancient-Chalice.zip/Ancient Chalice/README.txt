Ancient Chalice - Mistbloom Studios
==================================================

A gold chalice on a mossy stone pedestal. Day 2 (Relic) of October Prompt Props.

INSTALL - Drag and Drop (Nexo)
--------------
1. Copy Nexo/items/inkprops_chalice.yml into plugins/Nexo/items/
2. Copy the Nexo/pack/assets/ folder into plugins/Nexo/pack/assets/
3. Run /nexo reload all, then /nexo inventory to grab the pieces.

Requires Minecraft 1.21.4 or newer
