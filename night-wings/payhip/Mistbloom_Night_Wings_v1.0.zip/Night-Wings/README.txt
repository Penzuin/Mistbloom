Night Wings - Mistbloom Studios
==================================================

Six animated wing cosmetics for HMCCosmetics

INSTALL - Drag and Drop (Nexo)
--------------
1. Copy everything inside Nexo/plugins/ into your server's plugins/ folder
2. Run /nexo reload all, then /cosmetic reload
3. Open the menu with /cosmetic menu night_wings

Each pair has its own permission, like hmccosmetics.frostlight_wings

Requires Minecraft 1.21.4 or newer and HMCCosmetics
