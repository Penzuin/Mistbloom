Halloween Festival - Mistbloom Studios
==================================================

38 Halloween furniture pieces for a spooky autumn market: pumpkins, a witch's corner, a graveyard and the critters that live there.

INSTALL - Drag and Drop (Nexo)
--------------
1. Copy Nexo/items/hollowmere.yml into plugins/Nexo/items/
2. Copy the Nexo/pack/assets/ folder into plugins/Nexo/pack/assets/
3. Run /nexo reload all, then /nexo inventory to grab the pieces.

Requires Minecraft 1.21.4 or newer
