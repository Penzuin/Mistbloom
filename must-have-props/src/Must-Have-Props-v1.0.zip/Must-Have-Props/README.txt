Must-Have Props - Mistbloom Studios
==================================================

Everyday props for any build: storage, clutter, lights and town pieces

INSTALL - Drag and Drop (Nexo)
--------------
1. Copy Nexo/items/musthave.yml into plugins/Nexo/items/
2. Copy the Nexo/pack/assets/ folder into plugins/Nexo/pack/assets/
3. Run /nexo reload all, then /nexo inventory to grab the pieces.

Requires Minecraft 1.21.4 or newer
